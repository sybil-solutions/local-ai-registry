import json,sys,re,os,subprocess,random,collections,types,unittest,io
from pathlib import Path
fixtures=json.load(sys.stdin);out={}
root=Path('/work');root.mkdir(exist_ok=True)
for name,f in fixtures.items():
 p=root/name;p.mkdir();result={};out[name]=result
 ns={'__name__':'panel_under_test'};exec(compile(f['lru'][0],name+'/lru.py','exec'),ns)
 mod=types.ModuleType('lru_cache');mod.LRUCache=ns['LRUCache'];sys.modules['lru_cache']=mod
 if name=='control-a':exec(compile(f['lru'][1],name+'/test_lru.py','exec'),ns)
 tests=unittest.TestSuite()
 for v in list(ns.values()):
  if isinstance(v,type) and issubclass(v,unittest.TestCase):tests.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(v))
 stream=io.StringIO();res=unittest.TextTestRunner(stream=stream).run(tests)
 result['lru_authored_tests']={'count':res.testsRun,'success':res.wasSuccessful(),'log':stream.getvalue()}
 rng=random.Random(7319);steps=0
 for cap in [1,2,7,31]:
  cache=ns['LRUCache'](cap);ref=collections.OrderedDict()
  for _ in range(1000):
   k=rng.randrange(50)
   if rng.random()<.6:
    v=rng.choice([None,False,0,[],{'x':1},rng.randrange(100)]);cache.put(k,v);ref[k]=v;ref.move_to_end(k)
    if len(ref)>cap:ref.popitem(last=False)
   else:
    expect=ref.get(k);assert cache.get(k)==expect,(name,k,expect)
    if k in ref:ref.move_to_end(k)
   assert len(cache)==len(ref)
   for key in range(50):assert (key in cache)==(key in ref)
   steps+=1
 result['lru_reference_operations_passed']=steps
 script=p/'backup.sh';script.write_text(f['backup'][0]);script.chmod(0o755)
 fake=p/'bin';fake.mkdir();(fake/'date').write_text('#!/bin/sh\nprintf "%s\\n" "$TEST_STAMP"\n');(fake/'date').chmod(0o755)
 def trial(case,source_name,dest_name,count):
  d=p/case;d.mkdir();src=d/source_name;src.mkdir();(src/'document.txt').write_text('fixture contents');dest=d/dest_name
  calls=[]
  for i in range(count):
   env={**os.environ,'PATH':str(fake)+':'+os.environ['PATH'],'TEST_STAMP':f'20261123_{i:06d}'}
   run=subprocess.run(['bash',str(script),str(src),str(dest)],capture_output=True,text=True,env=env,timeout=5)
   calls.append({'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr})
   if run.returncode:break
  archives=list(dest.glob('*.tar.gz')) if dest.exists() else []
  return {'runs':len(calls),'archive_count':len(archives),'all_succeeded':all(x['returncode']==0 for x in calls),'last':calls[-1]}
 result['backup_normal_9_runs']=trial('normal','src','out',9)
 result['backup_valid_sibling_destination']=trial('sibling','src','src-backups',1)
 result['backup_newline_source_name']=trial('newline','src\nbreak','out',9)
print(json.dumps(out,indent=2))
