# Retained-profile panel review

Reviewed12 final answers: **7 counted passes with limitations; 5 counted failures**. Every reviewed response has empty automatic transport/loop flags. This review measures semantic task completion separately from those flags.

This is a retrospective, small-panel review. It is not an exhaustive model-quality benchmark, not evidence that longer context caused the failures, and not a comparison with a different runtime. No generated answer was repaired for grading. The machine-readable record contains each task, target and actual input tokens, output hash, verdict, limitations and CPU test evidence.

## Findings

| Task | Target input | Verdict | Finding |
|---|---:|---|---|
| lru | 32768 | fail | All eight supplied tests raise TypeError because LRUCache[str, int] subscripts a class that does not inherit Generic and defines no __class_getitem__. The class itself passes a direct-use reference oracle. |
| tcp | 32768 | pass_with_limitations | Covers congestion window, slow start, congestion avoidance, fast retransmit/recovery and timeout behaviour as a Reno-style introduction. |
| story | 32768 | pass_with_limitations | Complete lighthouse-keeper/message-in-bottle narrative with an ending; no transport truncation or obvious repetitive loop. |
| database | 32768 | pass_with_limitations | Includes the requested comparison table, write-heavy recommendation and relevant read/space/compaction caveats. |
| backup | 32768 | fail | Distinct-timestamp retention works, but same-second collision handling does not preserve the newest seven. Nine runs retained source versions0,2,3,4,5,6,7 and deleted newly created version8. |
| history | 32768 | pass_with_limitations | Exactly five paragraphs, covers speculation/leverage, monetary conditions, confidence, economic contraction and institutional consequences. |
| lru | 114688 | pass_with_limitations | All ten supplied unit tests and4000 independent reference operations pass; uses a dictionary and doubly linked list with recency promotion and eviction. |
| tcp | 114688 | fail | The step-by-step algorithm states slow start continues while inflight<ssthresh. The controlling comparison is cwnd versus ssthresh; inflight may be lower than cwnd for an application-limited sender. |
| story | 114688 | pass_with_limitations | 655 words with a lighthouse keeper, bottle message and coherent response/ending; broadly meets approximately600-word scope. |
| database | 114688 | pass_with_limitations | Includes table and useful conditional LSM recommendation for sustained writes, with compaction, reads and space caveats. |
| backup | 114688 | fail | Retention order is reversed: ascending sort followed by tail -n +8 deletes the newest archives. Nine distinct-timestamp runs retain versions0–6 rather than2–8; the ninth newly created backup is immediately deleted. |
| history | 114688 | fail | The pre-crash causal paragraph includes Hawley-Smoot tariff effects as an existing strain before the late1929 trigger. Smoot-Hawley was signedJune17,1930, so the answer conflates later Depression developments with causes of the1929 crash. |

## Code and shell verification

Both LRU classes pass4000 deterministic random operations against an OrderedDict oracle (capacities1,2,7,31, seed7319). However, every32K authored test fails before exercising the class because it uses generic subscription on a nongeneric class. The112K supplied test suite passes10/10.

Backup tests wrote source versions0–8, ran the unmodified script nine times, then opened retained tarballs to check contents rather than merely counting filenames. With distinct timestamps,32K retains the newest versions2–8;112K incorrectly retains the oldest0–6. With one fixed timestamp to exercise advertised collision handling,32K retains0,2–7 and deletes newest version8. All those script invocations return exit0, illustrating why transport success is insufficient.

Execution was CPU-only in a network-disabled runc container: no GPU flags or host mounts, read-only root,256MiB memory,0.5CPU,64PIDs,20-second CPU ulimit, no capabilities, no-new-privileges, UID65534, disposable work/tmp tmpfs. The existing pinned vLLM image supplied interpreters only; no model or server was launched. Full CPU evidence and the harness hash are in `panel-reviewed.json`. No live ledger, runner, core or queue was edited.

## Rubric and limits

Central code/test failures, retention-order defects and material chronology/algorithm mistakes count as failures. Lesser simplifications count as passes with explicit caveats. In particular, the32K story is885 words versus requested about600; this is an observed scope weakness, but no numeric hard cutoff was preregistered, so the review did not invent one after seeing the output. The112K story is655 words. Both history answers contain exactly five paragraphs.

The TCP review is anchored in [RFC5681](https://www.rfc-editor.org/rfc/rfc5681): slow start depends on the congestion window relative to the threshold, not the current flight size; reductions use FlightSize in its classical loss response. The [U.S. Senate history](https://www.senate.gov/artandhistory/history/minute/Senate_Passes_Smoot_Hawley_Tariff.htm) dates Smoot-Hawley signing to June17,1930, supporting the112K chronology finding. Database amplification claims depend on storage-engine implementation/workload, and narrative quality remains subjective.

Use the results to disclose concrete model limitations. Do not label all12 answers correct because requests completed naturally, and do not present7/12 as a standardized public benchmark score.
