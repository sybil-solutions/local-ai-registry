"""Check proposed functions against the task fixtures inside a disposable offline container."""

import ast
import builtins
import copy
import json
import re
import sys

FUNCTIONS = {
    name: getattr(builtins, name)
    for name in (
        "abs",
        "all",
        "any",
        "bool",
        "dict",
        "enumerate",
        "int",
        "len",
        "list",
        "max",
        "min",
        "range",
        "set",
        "sum",
        "tuple",
        "ValueError",
        "zip",
    )
}
METHODS = {
    "add",
    "append",
    "copy",
    "discard",
    "extend",
    "get",
    "items",
    "keys",
    "pop",
    "setdefault",
    "update",
    "values",
}
DENIED = (
    ast.Import,
    ast.ImportFrom,
    ast.Global,
    ast.Nonlocal,
    ast.ClassDef,
    ast.Lambda,
    ast.With,
    ast.AsyncFunctionDef,
)


def compiled_function(answer, name):
    blocks = re.findall(
        r"```(?:python|py)?\s*\n(.*?)```", answer, flags=re.IGNORECASE | re.DOTALL
    )
    for source in reversed(blocks or [answer]):
        try:
            body = ast.parse(source.strip()).body
        except SyntaxError:
            continue
        for item in reversed(body):
            if not isinstance(item, ast.FunctionDef) or item.name != name:
                continue
            if item.decorator_list:
                raise ValueError("Decorated function")
            for node in ast.walk(item):
                if isinstance(node, DENIED) or (
                    isinstance(node, ast.Attribute) and node.attr not in METHODS
                ):
                    raise ValueError("Unsupported operation in repair")
                if isinstance(node, ast.Name) and node.id.startswith("__"):
                    raise ValueError("Unsupported name")
            namespace = {"__builtins__": FUNCTIONS}
            # Executed only inside the disposable, resource-limited test container.
            exec(  # noqa: S102
                compile(ast.Module(body=[item], type_ignores=[]), "<repair>", "exec"),
                namespace,
            )
            return namespace[name]
    raise ValueError("No complete replacement function")


def check(task, answer):
    fn = compiled_function(answer, task["function"])
    failures = []
    for number, (args, expected) in enumerate(task["cases"], 1):
        given = copy.deepcopy(args)
        try:
            got = fn(*given)
            ok = (
                type(got) is type(expected)
                and got == expected
                and expected != {"raises": "ValueError"}
            )
        except Exception as exc:  # noqa: BLE001 - unexpected candidate exceptions fail the case
            ok = type(exc) is ValueError and expected == {"raises": "ValueError"}
        if not ok or (task["id"] in ("config", "batches") and given != args):
            failures.append(str(number))
    return (
        (False, "Failed regression cases " + ", ".join(failures) + ".")
        if failures
        else (True, f"Passed all {len(task['cases'])} regression cases.")
    )


if __name__ == "__main__":
    records = json.load(sys.stdin)
    for record in records:
        try:
            passed, reason = check(record["fixture"], record["answer"])
        except (ValueError, NameError, SyntaxError, TypeError) as exc:
            passed, reason = False, str(exc)
        print(
            json.dumps({"digest": record["digest"], "passed": passed, "reason": reason})
        )
