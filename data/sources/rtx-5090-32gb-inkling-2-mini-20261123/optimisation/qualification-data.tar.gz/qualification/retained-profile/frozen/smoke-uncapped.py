#!/usr/bin/env python3
"""Exercise a localhost Inkling API; report completion timing and tool correctness."""
import base64, json, struct, time, urllib.request, zlib

def call(payload):
    payload.update(model='Inkling-2-Mini', temperature=0)
    start = time.monotonic()
    req = urllib.request.Request('http://127.0.0.1:8102/v1/chat/completions', data=json.dumps(payload).encode(), headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=240) as response:
        result = json.load(response)
    elapsed = time.monotonic() - start
    print(json.dumps({'seconds':round(elapsed,2),'usage':result.get('usage'),'message':result['choices'][0]['message']}))
    return result['choices'][0]['message']

message = call({'messages':[{'role':'user','content':'What is 17 times 23? Give the answer briefly.'}]})
assert '391' in (message.get('content') or ''), message
message = call({'messages':[{'role':'user','content':'Use the get_weather tool for London.'}], 'tools':[{'type':'function','function':{'name':'get_weather','description':'Get current weather for a city','parameters':{'type':'object','properties':{'city':{'type':'string'}},'required':['city']}}}], 'tool_choice':'auto'})
assert message.get('tool_calls'), message
assert message['tool_calls'][0]['function']['name'] == 'get_weather', message
assert 'London' in message['tool_calls'][0]['function']['arguments'], message
call({'messages':[{'role':'user','content':'Write a Python function that merges overlapping intervals. Include a short explanation and three assertions testing edge cases.'}]})
# Complete a real tool exchange using synthetic, unambiguous tool output.
followup = call({'messages':[
    {'role':'user','content':'Use the get_weather tool for London.'},
    message,
    {'role':'tool','tool_call_id':message['tool_calls'][0]['id'],
     'content':'{"city":"London","temperature_c":13,"conditions":"rain"}'}]})
assert '13' in (followup.get('content') or ''), followup

# Generate a deterministic 128x128 blue PNG fixture without external assets.
def chunk(kind, data):
    return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data))
png = b'\x89PNG\r\n\x1a\n'
png += chunk(b'IHDR',struct.pack('>IIBBBBB',128,128,8,2,0,0,0))
png += chunk(b'IDAT',zlib.compress((b'\0'+b'\0\0\xff'*128)*128))
png += chunk(b'IEND',b'')
vision = call({'messages':[{'role':'user','content':[
    {'type':'text','text':'What is the dominant color in this image? Answer with one color.'},
    {'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(png).decode()}}
]}]})
assert 'blue' in (vision.get('content') or '').lower(), vision

payload = {'model':'Inkling-2-Mini','messages':[{'role':'user','content':'Count from 1 to 5.'}],
           'stream':True,'stream_options':{'include_usage':True},'temperature':0}
req = urllib.request.Request('http://127.0.0.1:8102/v1/chat/completions',
    data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
start = time.monotonic()
first = None
content = ''
usage = None
done = False
with urllib.request.urlopen(req,timeout=180) as response:
    for line in response:
        if not line.startswith(b'data: '): continue
        data = line[6:].strip()
        if data == b'[DONE]':
            done = True
            break
        event = json.loads(data)
        usage = event.get('usage') or usage
        for choice in event.get('choices',[]):
            delta = choice.get('delta',{})
            if delta.get('content') or delta.get('reasoning_content'):
                if first is None: first = time.monotonic()-start
            content += delta.get('content') or ''
assert done and '5' in content, content
print(json.dumps({'stream_seconds':time.monotonic()-start,'first_token_seconds':first,'usage':usage,'content':content}))
print('PASS text, tool roundtrip, vision, streaming, and coding response')
