"""Replay Daily driver v1 against one local OpenAI-compatible configuration."""

import argparse
import json
import os
from pathlib import Path
from time import monotonic
from urllib.request import Request, urlopen


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--max-tokens", type=int, default=4096)
    args = parser.parse_args()
    if args.max_tokens <= 0:
        parser.error("--max-tokens must be positive")
    headers = {"Content-Type": "application/json"}
    if token := os.environ.get("DAILY_API_KEY"):
        headers["Authorization"] = "Bearer " + token
    tasks = json.loads(
        (
            Path(__file__).resolve().parents[2] / "public/lab/daily/tasks.json"
        ).read_text()
    )

    def request(prompt):
        body = {
            "model": args.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0,
            "chat_template_kwargs": {"enable_thinking": False},
            "thinking": {"type": "disabled"},
        }
        req = Request(
            args.base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(body).encode(),
            headers=headers,
        )
        start = monotonic()
        with urlopen(req, timeout=300) as response:
            result = json.load(response)
        elapsed = monotonic() - start
        choice = result["choices"][0]
        message = choice["message"]
        content = message.get("content") or ""
        reasoning = message.get("reasoning_content") or message.get("reasoning") or ""
        if "</think>" in content:
            embedded, content = content.rsplit("</think>", 1)
            reasoning = reasoning or embedded.removeprefix("<think>")
        return {
            "answer": content.strip(),
            "reasoning": reasoning,
            "seconds": round(elapsed, 4),
            "finish": choice.get("finish_reason"),
            "usage": result.get("usage"),
        }

    with args.output.open("x", encoding="utf-8") as out:
        request("Reply READY.")
        for repeat in (1, 2):
            for task in tasks if repeat == 1 else reversed(tasks):
                print(
                    json.dumps(
                        {
                            "task": task["id"],
                            "repeat": repeat,
                            **request(task["prompt"]),
                        }
                    ),
                    file=out,
                    flush=True,
                )


if __name__ == "__main__":
    main()
