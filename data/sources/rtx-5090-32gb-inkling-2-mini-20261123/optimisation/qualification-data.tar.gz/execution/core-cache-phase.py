#!/usr/bin/env python3
"""Reproducible single-GPU Inkling campaign; no output caps or clock changes."""
import argparse, hashlib, json, random, signal, statistics, subprocess as sp, time, urllib.request, threading
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/tmp/inkling-registry-review')
BASE=json.loads((REPO/'registry/launches/sglang-inkling-2-mini-rtx5090-128k.json').read_text())
URL='http://127.0.0.1:8102'
SAMPLING_TEMP=0.8
NAME='inkling-extended-trial'
PROMPTS={
 'prose':'Write a complete, original story of about 2500 words about a lighthouse keeper and a cartographer discovering that their maps disagree. Include dialogue, a genuine disagreement resolved through evidence, and a definite ending. Write the story itself, not an outline.',
 'code':'Write a complete Python standard-library-only module implementing a thread-safe bounded LRU cache with per-entry TTL, an injectable monotonic clock, get/set/delete/clear, hit/miss/eviction statistics and a get_or_compute method. Explain the concurrency contract. Include a complete unittest suite covering expiration, eviction, replacement, missing keys, falsey values, errors in the factory and concurrent access. Provide the full implementation and tests, without placeholders.',
 'reasoning':'Solve all the following problems, showing intermediate reasoning and a clearly numbered final answer for each. For each integer n from 11 through 30 inclusive, a bag contains n red balls and n+3 blue balls. Draw four balls uniformly without replacement. Compute the exact probability of exactly two red balls as a reduced fraction. Derive the formula once, then show the integer combinations, numerator, denominator, reduction and answer for every n. Do not skip any case.'
}
VARIANTS={'baseline':{},'gamma3':{'--speculative-dspark-block-size':'3'},'gamma11':{'--speculative-dspark-block-size':'11'},'chunk1024':{'--chunked-prefill-size':'1024'},'chunk4096':{'--chunked-prefill-size':'4096'}}

VARIANTS.update({'compact':{'env:SGLANG_RAGGED_VERIFY_MODE':'compact'},'draft-mxfp8':{'--speculative-dspark-lm-head-dtype':'mxfp8'}})

def shell(*a):return sp.check_output(a,text=True).strip()
def request(path,body=None,timeout=600):
 req=urllib.request.Request(URL+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)
 except urllib.error.HTTPError as e:
  raise RuntimeError(str(e)+': '+e.read().decode()[:500]) from e
def count(text):
 d=request('/v1/tokenize',{'model':'Inkling-2-Mini','prompt':text}); n=d.get('count') or d.get('length') or len(d.get('tokens',[]))
 if not n and text:raise RuntimeError('Tokenizer count unavailable')
 return n

def ready(port,name):
 end=time.monotonic()+600
 while time.monotonic()<end:
  if shell('docker','inspect','-f','{{.State.Running}}',name)!='true':raise RuntimeError(name+' exited')
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/v1/models',timeout=3) as r:model_info=json.load(r)
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/health_generate',timeout=240) as r:
    assert r.status==200
   return model_info
  except Exception:time.sleep(3)
 raise TimeoutError('Readiness exceeded 600 seconds')

def telemetry():
 try:return shell('nvidia-smi','--query-gpu=memory.used,memory.total,temperature.gpu,power.draw','--format=csv,noheader,nounits')
 except Exception:return None

def append(path,row):
 with path.open('a') as f:f.write(json.dumps(row)+'\n')

def cold():
 req=urllib.request.Request(URL+'/flush_cache?timeout=120',data=b'{}',headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=180) as r:
  if r.status!=200:raise RuntimeError('Cache flush failed')

def prompt(kind,size,seed,position=None):
 rng=random.Random(seed)
 words='amber birch cedar delta elm fern granite harbor iris juniper kelp lantern meadow north ocean pine quartz river stone timber upland violet willow yellow zephyr'.split()
 paragraphs=[' '.join(rng.choices(words,k=100)) for _ in range(max(1,size//100+20))]
 text='\n'.join(paragraphs)
 # Binary search character boundary, with tokenizer as authority. Include unique prefix to avoid cross-request reuse.
 prefix=f'Synthetic reference document {seed}. The document is background material.\n'
 lo,hi=0,len(text)
 while lo<hi:
  mid=(lo+hi+1)//2
  if count(prefix+text[:mid])<=size-350:lo=mid
  else:hi=mid-1
 text=text[:lo]
 if kind=='recall':
  needle=f'beacon-{seed}-cobalt';idx=int(len(text)*position)
  text=text[:idx]+'\nThe secret lookup code is '+needle+'.\n'+text[idx:]
  task='Return only the exact secret lookup code from the reference document.'
 elif kind=='prefill':task='Return only the word READY.';needle='READY'
 elif kind=='probe':task='Explain how a write-ahead log supports recovery after a crash, in about 400 words, using one concrete example.';needle=None
 else:task=PROMPTS[kind];needle=None
 return prefix+text+'\nEND OF REFERENCE DOCUMENT.\nTask: '+task,needle

def sample(profile,phase,kind,size,seed,position=None):
 p,needle=prompt(kind,size,seed,position)
 cold()
 payload={'model':'Inkling-2-Mini','messages':[{'role':'user','content':p}],'temperature':0 if needle else SAMPLING_TEMP,'seed':seed,'stream':True,'stream_options':{'include_usage':True}}
 req=urllib.request.Request(URL+'/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 row={'unix_start':time.time(),'profile':profile,'phase':phase,'kind':kind,'target_input':size,'seed':seed,'position':position,'prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'gpu_before':telemetry()}
 start=time.monotonic();first=None;visible_first=None;pieces=[];content=[];reasoning=[];window=None;usage=None;finish=None;done=False
 try:
  with urllib.request.urlopen(req,timeout=600) as r:
   for line in r:
    if not line.startswith(b'data:'):continue
    raw=line[5:].strip()
    if raw==b'[DONE]':done=True;break
    d=json.loads(raw);usage=d.get('usage') or usage
    for choice in d.get('choices',[]):
     finish=choice.get('finish_reason') or finish;delta=choice.get('delta',{})
     thought=delta.get('reasoning_content') or delta.get('reasoning') or '';visible=delta.get('content') or '';piece=thought+visible
     now=time.monotonic()
     if piece:
      if first is None:first=now
      pieces.append(piece);content.append(visible);reasoning.append(thought)
      if visible and visible_first is None:visible_first=now
      if window is None and now-first>=30:window=(''.join(pieces),now-first)
  end=time.monotonic();whole=''.join(pieces);span=end-(first or start);window_text,window_span=window or (whole,span)
  n=count(whole);wn=count(window_text)
  row.update(seconds=end-start,ttft=None if first is None else first-start,visible_ttft=None if visible_first is None else visible_first-start,decode_seconds=span,accepted_text_tokens=n,accepted_text_tps=n/span if span else None,window_tokens=wn,window_seconds=window_span,window_tps=wn/window_span if window_span else None,usage=usage,finish=finish,done=done,content=''.join(content),reasoning=''.join(reasoning),gpu_after=telemetry())
  row['passed']=done and finish=='stop' and (needle is None or needle==row['content'].strip())
  if needle:row['expected']=needle
  if kind=='prose':
   row['visible_words']=len(row['content'].split())
   row['scope_check']=1000<=row['visible_words']<=5000
   row['passed']=row['passed'] and row['scope_check']
 except Exception as e:row.update(error=repr(e),seconds=time.monotonic()-start,passed=False,gpu_after=telemetry())
 append(ROOT/'samples.jsonl',row)
 print(json.dumps({k:row.get(k) for k in ('profile','phase','kind','target_input','seed','seconds','ttft','window_tps','finish','passed','error')}),flush=True)
 return row

def launch(profile,changes):
 import shlex
 p=json.loads(json.dumps(BASE))
 for k,v in changes.items():
  if k.startswith('env:'):
   p['env'][k[4:]]=v;continue
  if k in p['args']:p['args'][p['args'].index(k)+1]=v
  else:p['args'] += [k,v]
 args=['docker','run','-d','--name',NAME,*sum([shlex.split(f) for f in p['flags']],[]),'-p','127.0.0.1:8102:30000','-v',str(Path.home()/'.cache/huggingface/hub')+':/root/.cache/huggingface/hub:ro']
 for k,v in p['env'].items():args+=['-e',k+'='+v]
 args+=['--entrypoint','python3',p['image'],*p['args']]
 (ROOT/(profile+'-launch.json')).write_text(json.dumps(args,indent=2))
 shell(*args);ready(8102,NAME)
 (ROOT/(profile+'-server-info.json')).write_text(json.dumps(request('/get_server_info'),indent=2))
 print('READY '+profile,flush=True)

def stop(profile):
 if sp.run(['docker','inspect',NAME],capture_output=True).returncode: return
 logs=sp.run(['docker','logs',NAME],capture_output=True,text=True)
 (ROOT/(profile+'-server-'+str(int(time.time()))+'.log')).write_text(logs.stdout+logs.stderr)
 sp.run(['docker','rm','-f',NAME],capture_output=True)

def screen(profile):
 rows=[]
 for repeat in range(2):
  for kind in (list(PROMPTS) if repeat==0 else list(PROMPTS)[::-1]):
   rows.append(sample(profile,'screen',kind,8192,1000+repeat*10+list(PROMPTS).index(kind)))
   if not rows[-1]['passed']:raise RuntimeError('Screen request failed')
  rows.append(sample(profile,'screen','prefill',32768,2000+repeat))
 return rows

def select():
 rows=[json.loads(x) for x in (ROOT/'samples.jsonl').read_text().splitlines()]
 baseline={(r['kind'],r['seed']):r for r in rows if r['profile']=='baseline' and r['phase']=='screen'}
 confirmed={(r['kind'],r['seed']):r for r in rows if r['profile']=='baseline-repeat' and r['phase']=='screen'}
 comparisons={}
 for name in VARIANTS:
  if name=='baseline':continue
  cand=[r for r in rows if r['profile']==name and r['phase']=='screen']
  if len(cand)!=8 or not all(r['passed'] for r in cand):continue
  if any((r['kind'],r['seed']) not in baseline or (r['kind'],r['seed']) not in confirmed for r in cand):
   comparisons[name]={'eligible':False,'reason':'Incomplete independent baseline confirmation'};continue
  if any(not 1000<=len(r.get('content','').split())<=5000 for r in cand if r['kind']=='prose'):
   comparisons[name]={'eligible':False,'reason':'Prose scope regression'};continue
  rates=[];per={};prefill=[];latency={}
  for r in cand:
   key=(r['kind'],r['seed']);refs=[baseline[key],confirmed[key]]
   if r['kind']=='prefill':prefill.append(min(x['ttft'] for x in refs)/r['ttft']);continue
   ratio=r['window_tps']/max(x['window_tps'] for x in refs)
   rates.append(ratio);per.setdefault(r['kind'],[]).append(ratio)
   latency.setdefault(r['kind'],[]).append(r['seconds']/min(x['seconds'] for x in refs))
  med=statistics.median(rates);worst=min(statistics.median(x) for x in per.values());pf=statistics.median(prefill)
  worst_latency=max(statistics.median(x) for x in latency.values())
  ok=((med>=1.05 and worst>=0.9) or (pf>=1.05 and med>=1 and worst>=0.9)) and worst_latency<=1.1
  comparisons[name]={'median_decode_ratio':med,'worst_workload_ratio':worst,'prefill_ttft_ratio':pf,'worst_answer_latency_ratio':worst_latency,'eligible':ok}
 eligible=[n for n,v in comparisons.items() if v['eligible']]
 winner=max(eligible,key=lambda n:comparisons[n]['median_decode_ratio']) if eligible else 'baseline'
 result={'winner':winner,'comparisons':comparisons};(ROOT/'selection.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
 return winner

def validate(profile):
 for repeat in range(3):
  for size in (8192,32768,114688):
   for kind in PROMPTS:
    r=sample(profile,'validation',kind,size,3000+repeat*100+size+list(PROMPTS).index(kind))
    if 'error' in r or not r.get('done'):raise RuntimeError('Validation transport failure')
 for seed in (9001,9002):
  for position in (0,0.5,1):
   r=sample(profile,'recall', 'recall',126000,seed,position)
   if not r['passed']:raise RuntimeError('Recall failed')
 # Use uncapped synthetic tool/vision smoke; retain its assertions.
 source=(Path.home()/'.local/share/inkling/smoke.py').read_text().replace('127.0.0.1:8101','127.0.0.1:8102').replace(", max_tokens=2048",'').replace(",'max_tokens':512",'')
 with (ROOT/'validation-smoke.log').open('w') as log:sp.run(['python3','-c',source],stdout=log,stderr=sp.STDOUT,timeout=900,check=True)
 # Frozen Daily quality tasks, with output cap removed for this registry campaign.
 daily_path=Path.home()/'Work/karimi.info/benchmarks/daily/run.py'
 daily_source=daily_path.read_text().replace('            \"max_tokens\": args.max_tokens,\n','')
 (ROOT/'daily-run-uncapped.py').write_text(daily_source)
 launch_code='__file__='+repr(str(daily_path))+';\n'+daily_source
 with (ROOT/'daily.log').open('w') as log:
  sp.run(['python3','-c',launch_code,'--base-url',URL+'/v1','--model','Inkling-2-Mini','--output',str(ROOT/'daily.jsonl')],stdout=log,stderr=sp.STDOUT,timeout=1800,check=True)
 # Keep a 15 minute sequential load at 8K/32K. Every fifth request is an exact sentinel probe.
 started=time.monotonic();i=0
 while time.monotonic()-started<900:
  kind='prefill' if i%5==4 else list(PROMPTS)[i%3]
  r=sample(profile,'soak',kind,32768 if i%2 else 8192,12000+i)
  if 'error' in r or not r.get('done'):raise RuntimeError('Soak transport failure')
  probe=sample(profile,'soak','probe',8192,22000+i)
  if 'error' in probe or not probe.get('done'):raise RuntimeError('Soak probe transport failure')
  i+=1
 (ROOT/'soak-duration.json').write_text(json.dumps({'seconds':time.monotonic()-started,'load_cycles':i}))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['screen','validate']);parser.add_argument('--profile',default='baseline');parser.add_argument('--profiles',nargs='+',default=['baseline','chunk1024','chunk4096','baseline-repeat']);args=parser.parse_args()
 def interrupt(*a):raise KeyboardInterrupt()
 signal.signal(signal.SIGTERM,interrupt)
 status={'phase':args.phase};active='unknown'
 monitor_stop=threading.Event()
 def monitor():
  while not monitor_stop.is_set():
   append(ROOT/(args.phase+'-telemetry.jsonl'),{'unix_seconds':time.time(),'gpu':telemetry()})
   monitor_stop.wait(2)
 monitor_thread=threading.Thread(target=monitor,daemon=True);monitor_thread.start()
 try:
  shell('docker','stop','--time','30','inkling-mini')
  if args.phase=='screen':
   viable=[]
   for active in args.profiles:
    if active=='baseline-repeat' and 'baseline' not in args.profiles and not viable:
     print('No viable extra candidate; no redundant baseline repeat',flush=True);continue
    try:
     launch(active,VARIANTS.get(active,{}));screen(active)
     if active not in ('baseline','baseline-repeat'):viable.append(active)
    except Exception as e:append(ROOT/'failures.jsonl',{'profile':active,'error':repr(e)});print(active+' FAILED '+repr(e),flush=True)
    finally:stop(active)
   status['winner']=select()
  else:
   active=args.profile;launch(active,VARIANTS[active]);validate(active)
  status['completed']=True
 except BaseException as e:status['error']=repr(e)
 finally:
  stop(active);shell('docker','start','inkling-mini')
  try:ready(8101,'inkling-mini');status['restored']=True
  except Exception as e:status['restoration_error']=repr(e)
  monitor_stop.set();monitor_thread.join(timeout=5)
  (ROOT/(args.phase+'-status.json')).write_text(json.dumps(status,indent=2));print(status,flush=True)
